
package com.chatapp.activities
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.chatapp.adapters.ChatAdapter
import com.chatapp.databinding.ActivityChatBinding
import com.chatapp.models.Chat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue

class ChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatBinding
    private val chats = ArrayList<Chat>()
    private val senderId = FirebaseAuth.getInstance().uid!!
    private lateinit var receiverId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        receiverId = intent.getStringExtra("uid")!!
        val chatId = senderId + receiverId

        val adapter = ChatAdapter(chats, senderId)
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.sendBtn.setOnClickListener {
            val map = hashMapOf(
                "senderId" to senderId,
                "receiverId" to receiverId,
                "message" to binding.message.text.toString(),
                "timestamp" to FieldValue.serverTimestamp()
            )
            FirebaseFirestore.getInstance()
                .collection("Chats")
                .document(chatId)
                .collection("messages")
                .add(map)
            binding.message.text.clear()
        }

        FirebaseFirestore.getInstance()
            .collection("Chats")
            .document(chatId)
            .collection("messages")
            .orderBy("timestamp")
            .addSnapshotListener { value, _ ->
                chats.clear()
                for (doc in value!!) chats.add(doc.toObject(Chat::class.java))
                adapter.notifyDataSetChanged()
            }
    }
}

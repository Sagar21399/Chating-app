
package com.chatapp.activities
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.chatapp.adapters.UserAdapter
import com.chatapp.databinding.ActivityUsersBinding
import com.chatapp.models.User
import com.google.firebase.firestore.FirebaseFirestore

class UsersActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUsersBinding
    private val users = ArrayList<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUsersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter = UserAdapter(users) {
            val i = Intent(this, ChatActivity::class.java)
            i.putExtra("uid", it.uid)
            startActivity(i)
        }

        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        FirebaseFirestore.getInstance().collection("Users")
            .addSnapshotListener { value, _ ->
                users.clear()
                for (doc in value!!) users.add(doc.toObject(User::class.java))
                adapter.notifyDataSetChanged()
            }
    }
}

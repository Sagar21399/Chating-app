
package com.chatapp.activities
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.chatapp.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.registerBtn.setOnClickListener {
            auth.createUserWithEmailAndPassword(
                binding.email.text.toString(),
                binding.password.text.toString()
            ).addOnSuccessListener {
                val uid = auth.currentUser!!.uid
                val map = hashMapOf(
                    "uid" to uid,
                    "name" to binding.name.text.toString(),
                    "email" to binding.email.text.toString(),
                    "status" to "online"
                )
                FirebaseFirestore.getInstance().collection("Users").document(uid).set(map)
                finish()
            }
        }
    }
}
